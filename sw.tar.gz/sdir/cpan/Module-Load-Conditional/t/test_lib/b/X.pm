package X;
use strict;

our $VERSION = '0.02';

1;
